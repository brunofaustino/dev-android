package br.com.fernandosousa.brewerapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ToggleButton;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        Button botao  = (Button)findViewById(R.id.botaoCadastro);
        botao.setOnClickListener(clickCadastro());
    }

    public View.OnClickListener clickCadastro(){
        return new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                EditText nomeProduto = (EditText)findViewById(R.id.nomeProduto);
                EditText valorProduto = (EditText)findViewById(R.id.valorProduto);
                EditText categoriaProduto = (EditText)findViewById(R.id.categoriaProduto);
                CheckBox cxFavotito = (CheckBox) findViewById(R.id.ckFavorito);
                //EditText precoRoupa = (EditText)findViewById(R.id.precoRoupa);

                String textoNomeProduto = nomeProduto.getText().toString();
                String textoValorProduto = valorProduto.getText().toString();
                String textoCategoriaProduto = categoriaProduto.getText().toString();
                //String textoEn = cxFavotito.getText().toString();
                //String textoPrecoRoupa = precoRoupa.getText().toString();

                final CheckBox check = (CheckBox) findViewById(R.id.ckFavorito);
                boolean checkFavorito = check.isChecked();

                //final ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
                //boolean toggleOrigem = toggle.isChecked();

                //RadioGroup radioGroup = (RadioGroup) findViewById(R.id.grupoBrilho);
                //int idRadio = radioGroup.getCheckedRadioButtonId();

                //RadioButton botaoSelecionado = (RadioButton) findViewById(idRadio);
                //String textoRadio = botaoSelecionado.getText().toString();

                Intent returnIntent = new Intent();
                returnIntent.putExtra("nomeProduto", textoNomeProduto);
                returnIntent.putExtra("valorProduto",textoValorProduto);
                returnIntent.putExtra("categoriaProduto",textoCategoriaProduto);
                returnIntent.putExtra("favorito", checkFavorito);
                //returnIntent.putExtra("precoRoupa",textoPrecoRoupa);

                //returnIntent.putExtra("origem", toggleOrigem);
                //returnIntent.putExtra("brilho", textoRadio);

                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
        };
    }
}
