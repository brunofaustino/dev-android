package br.com.fernandosousa.brewerapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrador on 25/09/2017.
 */

public class SimpleAdapter extends BaseAdapter {

    Context context;

    String[] listaRoupass = new String[]{
            "Bermuda", "Camiseta", "Calça", "Boné", "Tenis", "Gravata"
    };

    List<String> listProduto = new ArrayList<>();

    public SimpleAdapter(Context context, List<Produto> listProduto){this.context = context;}

    @Override
    public int getCount() {
        return listaRoupass.length;
    }

    @Override
    public Object getItem(int i) {
        return listaRoupass[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int posicao, View view, ViewGroup viewGroup) {
        String cerveja = listaRoupass[posicao];
        TextView t = new TextView(context);

        float dip = 50;
        float densidade = context.getResources().getDisplayMetrics().density;
        int px = (int) (dip * densidade + 0.5f);
        t.setHeight(px);
        t.setText(cerveja);

        return t;
    }
}
