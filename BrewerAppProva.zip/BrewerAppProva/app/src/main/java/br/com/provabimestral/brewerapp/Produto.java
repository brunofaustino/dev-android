package br.com.fernandosousa.brewerapp;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fsousa on 09/09/2017.
 */

public class Produto {
    String nome;

    public Produto(String nome) {
        this.nome = nome;
    }

    public static List<Produto> getProduto(){
        List<Produto> produto = new ArrayList<Produto>();
        produto.add(new Produto("Bermuda"));
        produto.add(new Produto("Camiseta"));
        produto.add(new Produto("Calça"));
        produto.add(new Produto("Boné"));
        produto.add(new Produto("Tenis"));
        produto.add(new Produto("Gravata"));

        return produto;
    }

}
